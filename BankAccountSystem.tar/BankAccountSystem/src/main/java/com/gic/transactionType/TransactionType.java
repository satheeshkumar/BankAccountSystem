package com.gic.transactionType;


/*
 * author satheesh
 */
public class TransactionType {


	public static final TransactionType DEPOSIT = null;
	public static final TransactionType WITHDRAWAL = null;
		
		// To Identify Deposit / Withdrawl case sceneario handling
	    public static TransactionType fromString(String s) {
	        if (s.equalsIgnoreCase("D")) {
	            return DEPOSIT;
	        } else if (s.equalsIgnoreCase("W")) {
	            return WITHDRAWAL;
	        } else {
	            throw new IllegalArgumentException("Invalid transaction type: " + s);
	        }
	    }
	

}
