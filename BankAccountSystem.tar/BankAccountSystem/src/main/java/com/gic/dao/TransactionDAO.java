package com.gic.dao;

import java.util.Date;

import com.gic.transactionType.TransactionType;

public interface TransactionDAO {

	 public void Transaction(Date date, String account, TransactionType type, double amount);
}
