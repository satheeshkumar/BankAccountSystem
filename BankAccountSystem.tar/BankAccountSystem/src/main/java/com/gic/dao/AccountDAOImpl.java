package com.gic.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;

/*
 * author satheesh
 */
public class AccountDAOImpl {

	private static final Logger logger = LogManager.getLogger(AccountDAOImpl.class);
	private String accountNumber;
	private List<Transaction> transactions;

	public AccountDAOImpl(String accountNumber) {
		this.accountNumber = accountNumber;
		this.transactions = new ArrayList<>();
	}

	/*
	 * For addTransaction(Transaction transaction) throws Exception
	 * 
	 * return transaction;
	 */

	public void addTransaction(Transaction transaction) throws Exception {
		// Ensure the first transaction is a deposit
		if (transactions.isEmpty()) {
			logger.info("The first transaction on an account should be a deposit.");
			return;
		}

		// Ensure the balance does not go below 0
		double balance = getBalance();
		if (balance < 0) {
			logger.info("Balance should not go below 0.");
			return;
		}

		transactions.add(transaction);
	}

	/*
	 * For getBalance() throws Exception
	 * 
	 * return balance;
	 */

	public double getBalance() throws Exception {
		double balance = 0;
		for (Transaction transaction : transactions) {
			balance += transaction.getAmount();
		}
		return balance;
	}

	/*
	 * For printStatement() throws Exception
	 * 
	 * 
	 */

	public void printStatement() throws Exception {
		logger.info("Account: " + accountNumber);
		logger.info("| Date     | Txn Id      | Type | Amount |");
		for (Transaction transaction : transactions) {
			System.out.printf("| %s | %s | %s | %.2f |\n", Bank.formatDate(transaction.getDate()), transaction.getId(),
					transaction.getType(), transaction.getAmount());
		}
	}

	/*
	 * For printStatement(String yearMonth, List<InterestRule> interestRules))
	 * throws Exception
	 * 
	 * args yearMonth args List<InterestRule> interestRules
	 */

	public void printStatement(String yearMonth, List<InterestRule> interestRules) throws Exception {
		logger.info("Account: " + accountNumber);
		logger.info("| Date     | Txn Id      | Type | Amount | Balance |");

		List<Transaction> applicableTransactions = new ArrayList<>();

		for (Transaction transaction : transactions) {
			if (Bank.formatDate(transaction.getDate()).startsWith(yearMonth)) {
				applicableTransactions.add(transaction);
			}
		}

		Collections.sort(applicableTransactions, Comparator.comparing(Transaction::getDate));

		double balance = getBalance();
		for (Transaction transaction : applicableTransactions) {
			System.out.printf("| %s | %s | %s | %.2f | %.2f |\n", Bank.formatDate(transaction.getDate()),
					transaction.getId(), transaction.getType(), transaction.getAmount(), balance);
			balance += transaction.getAmount();
		}

		double totalInterest = calculateInterest(yearMonth, interestRules);
		System.out.printf("| %s |             | I    | %.2f | %.2f |\n", getLastDayOfMonth(yearMonth), totalInterest,
				balance + totalInterest);
	}

	/*
	 * For calculateInterest(String yearMonth, List<InterestRule> interestRules)
	 * throws Exception
	 * 
	 * args yearMonth args List<InterestRule> interestRules
	 * 
	 * return totalInterest
	 */
	private double calculateInterest(String yearMonth, List<InterestRule> interestRules) throws Exception {
		double totalInterest = 0;
		double balance = getBalance();

		for (InterestRule rule : interestRules) {
			if (Bank.formatDate(rule.getDate()).startsWith(yearMonth)) {
				double rate = rule.getRate() / 100.0;
				totalInterest += (balance * rate / 365.0); // Daily interest calculation
			}
		}

		return totalInterest;
	}

	/*
	 * For getLastDayOfMonth(String yearMonth) throws Exception
	 * 
	 * args yearMonth * return yearMonth
	 */

	private String getLastDayOfMonth(String yearMonth) throws Exception {
		int year = Integer.parseInt(yearMonth.substring(0, 4));
		int month = Integer.parseInt(yearMonth.substring(4, 6));
		int lastDay = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
		return String.format("%04d%02d%02d", year, month, lastDay);
	}

}
