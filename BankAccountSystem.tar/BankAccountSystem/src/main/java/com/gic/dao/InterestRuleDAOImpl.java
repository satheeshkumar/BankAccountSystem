package com.gic.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;

/*
 * author satheesh
 */
public class InterestRuleDAOImpl {

	private static final Logger logger = LogManager.getLogger(InterestRuleDAOImpl.class);
	private String yearMonth;

	private List<Transaction> transaction = new ArrayList<Transaction>();
	List<InterestRule> interestRules = new ArrayList<InterestRule>();
	
	
	/*
	 * For getBalance()
	 * 
	 * return balance;
	 */

	public double getBalance() throws Exception {
		double balance = 0;
		for (Transaction transaction : transaction) {
			balance += transaction.getAmount();
		}
		return balance;
	}

	/*
	 * For InterestRule(Date date, String ruleId, double rate) throws Exception
	 * 
	 * return totalInterest;
	 */
	public double InterestRule(Date date, String ruleId, double rate) throws Exception {

		double totalInterest = 0;
		double balance = getBalance();

		for (InterestRule rule : interestRules) {
			if (Bank.formatDate(rule.getDate()).startsWith(yearMonth)) {
				rate = rule.getRate() / 100.0;
				totalInterest += (balance * rate / 365.0); // Daily interest calculation
			}
		}

		return totalInterest;
	}

}
