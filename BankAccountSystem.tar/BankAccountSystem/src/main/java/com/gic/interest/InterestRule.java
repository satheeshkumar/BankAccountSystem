package com.gic.interest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.transaction.Transaction;
import com.gic.transactionType.TransactionType;

/*
 * author satheesh
 */
public class InterestRule {

	// Logger Implementation
	private static final Logger logger = LogManager.getLogger(InterestRule.class);

	private static List<Transaction> transactions;

	static Scanner scanner;
	private Date date = new Date();
	static List<InterestRule> interestRules=new ArrayList<InterestRule>();

	static double totalInterest;
	private String ruleId;
	private double rate;

	public InterestRule(Date date, String ruleId, double rate) {
		this.date = date;
		this.ruleId = ruleId;
		this.rate = rate;
	}

	public Date getDate() {
		return date;
	}

	public String getRuleId() {
		return ruleId;
	}

	public double getRate() {
		return rate;
	}

	/*
	 * For defineInterestRules(Scanner scanner, Bank bank) throws Exception
	 * 
	 * args Interest rules details in <Date> <RuleId> <Rate in %> format
	 */
	private static double defineInterestRules(Date date, List<InterestRule> interestRules) throws Exception {
		// TODO Auto-generated method stub

		while (true) {
			System.out.println("Please enter transaction details in <Date-YYYYMMdd> <RuleId-0X> <Rate-%> format");
			System.out.println("(or enter blank to go back to the main menu):");
			System.out.println("> ");

			String input = scanner.nextLine();

			if (input.isEmpty()) {
				break;
			}

			String[] parts = input.split(" ");

			if (parts.length != 3) {
				System.out.println("Invalid input format. Please try again.");
				continue;
			}

			String yearMonth = parts[0];
			String ruleID = parts[1];
			String rateVal = parts[2];

			double totalInterest = 0;
			double balance = getBalance();
			double rate;
			for (InterestRule rule : interestRules) {
				if (Bank.formatDate(rule.getDate()).startsWith(yearMonth)) {
					rate = rule.getRate() / 100.0;
					totalInterest += (balance * rate / 365.0); // Daily interest calculation
				}
			}
		}
		return totalInterest;

	}

	public static double getBalance() {
		double balance = 0;
		try {
			for (Transaction transaction : transactions) {
				balance += (transaction.getType() == TransactionType.DEPOSIT ? transaction.getAmount()
						: -transaction.getAmount());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balance;
	}

}