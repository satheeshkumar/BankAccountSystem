package com.gic.account;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;


/*
 * author satheesh
 */
public class Account {
	private static final Logger logger = LogManager.getLogger(Account.class); 
    private String accountNumber;
    private List<Transaction> transactions;
    private double balance;
    
    
    
    public void setBalance(double balance) {
		this.balance = balance;
	}


	// Constructor 
    public Account(String accountNumber,double balance) throws Exception {
        this.accountNumber = accountNumber;
        this.transactions = new ArrayList<>();
        this.balance=getBalance();
    }
    
    
    /*
     * addTransaction(Date date,Transaction transaction) throws Exception
     * args (Date date,Transaction transaction)
     */
    public  void addTransaction(Date date,Transaction transaction) throws Exception{
        // Ensure the first transaction is a deposit
        if ( transaction.getType().equals("W")) {
        	if((getBalance() > 0) && (getBalance() > transaction.getAmount()))
        			{
        		
        				setBalance(getBalance() - transaction.getAmount());
        				System.out.println("The first transaction of an account should be a Deposit. So TransactionType shouldnot be Withdrawl");
        			}
        }
        
        	else if (transaction.getType().equals("D"))
        	{
        		setBalance(getBalance() + transaction.getAmount());
        	}
        
        // Ensure the balance does not go below 0
        double balance = getBalance();
        
        if (balance > 0 ) {
            System.out.println("Balance should not go below 0.");
            return;
        }
        
        else if (balance > 0 && !transactions.isEmpty() ) {
        	System.out.println(" Balance amount should be within Withdrawl limit");
        }
        
        
        //transactions.add(transaction.getDate(),transaction);
        
        transactions.add(transaction);
    }
    
    
    /*
     * getBalance(Transaction transaction) throws Exception
     * 
     */
    public double getBalance() throws Exception{
        double balance = 0;
        for (Transaction transaction : transactions) {
            balance += transaction.getAmount();
            
            
        }
        return balance;
    }
    
    
    /*
     * printStatement() throws Exception
     * args (Transaction transaction)
     */
    public void printStatement() throws Exception{
        System.out.println("Account: " + accountNumber);
        System.out.println("| Date     | Txn Id      | Type | Amount |");
        for (Transaction transaction : transactions) {
            System.out.printf("| %s | %s | %s | %.2f |\n",
                    Bank.formatDate(transaction.getDate()), transaction.getId(),
                    transaction.getType(), transaction.getAmount());
        }
    }
    
    /*
     * printStatement(String yearMonth, List<InterestRule> interestRules) throws Exception
     * args (String yearMonth, List<InterestRule> interestRules)
     */
    public void printStatement(String yearMonth, List<InterestRule> interestRules) throws Exception {
        System.out.println("Account: " + accountNumber);
        System.out.println("| Date     | Txn Id      | Type | Amount | Balance |");
        
        List<Transaction> applicableTransactions = new ArrayList<>();
        
        for (Transaction transaction : transactions) {
            if (Bank.formatDate(transaction.getDate()).startsWith(yearMonth)) {
                applicableTransactions.add(transaction);
            }
        }
        
        Collections.sort(applicableTransactions, Comparator.comparing(Transaction::getDate));
        
        double balance = getBalance();
        for (Transaction transaction : applicableTransactions) {
            System.out.printf("| %s | %s | %s | %.2f | %.2f |\n",
                    Bank.formatDate(transaction.getDate()), transaction.getId(),
                    transaction.getType(), transaction.getAmount(), balance);
            balance += transaction.getAmount();
        }
        
        double totalInterest = calculateInterest(yearMonth, interestRules);
        System.out.printf("| %s |             | I    | %.2f | %.2f |\n",
                getLastDayOfMonth(yearMonth), totalInterest, balance + totalInterest);
    }
    
    /*
     * method calculateInterest(String yearMonth, List<InterestRule> interestRules) throws Exception
     * args (String yearMonth, List<InterestRule> interestRules)
     */
    private double calculateInterest(String yearMonth, List<InterestRule> interestRules) throws Exception{
        double totalInterest = 0;
        double balance = getBalance();
        
        for (InterestRule rule : interestRules) {
            if (Bank.formatDate(rule.getDate()).startsWith(yearMonth)) {
                double rate = rule.getRate() / 100.0;
                totalInterest += (balance * rate / 365.0); // Daily interest calculation
            }
        }
        
        return totalInterest;
    }
    
    /*
     * method getLastDayOfMonth(String yearMonth) throws Exception
     * args yearMonth
     */
    private String getLastDayOfMonth(String yearMonth) throws Exception{
        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));
        int lastDay = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
        return String.format("%04d%02d%02d", year, month, lastDay);
    }
}