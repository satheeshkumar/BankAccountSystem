package com.gic;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;
import com.gic.transactionType.TransactionType;  

public class BankAccountSystemTest {

	private static final Logger logger = LogManager.getLogger(BankAccountSystemTest.class); 
	Bank bank = new Bank();
	@Test
	public void testBankAccountSystem() {

   Scanner scanner = new Scanner(System.in);
   Bank bank = new Bank();
   
   while (true) {
       System.out.println("Welcome to AwesomeGIC Bank! What would you like to do?");
       System.out.println("[T] Input transactions");
       System.out.println("[I] Define interest rules");
       System.out.println("[P] Print statement");
       System.out.println("[Q] Quit");
       System.out.println("> ");
       
       String choice = scanner.nextLine();
       
       switch (choice.toUpperCase()) {
           case "T":
				try {
					inputTransactions();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}
               break;
           case "I":
				try {
					defineInterestRules();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}
               break;
           case "P":
				try {
					printStatement();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}
               break;
           case "Q":
               System.out.println("Thank you for banking with AwesomeGIC Bank.");
               System.out.println("Have a nice day!");
               scanner.close();
               return;
           default:
               System.out.println("Invalid option. Please try again.");
               break;
       }
   }
	}
	
	 @Test
	 public void inputTransactions() throws Exception{
	        while (true) {
	            System.out.println("Please enter transaction details in <Date> <Account> <Type> <Amount> format");
	            System.out.println("(or enter blank to go back to the main menu):");
	            System.out.println("> ");
	            
	            //String input = scanner.nextLine();
	            
	            String input ="20230929 AC001 D 100.00";
	            
	            
	            if (input.isEmpty()) {
	                break;
	            }
	            
	            String[] parts = input.split(" ");
	            
	            if (parts.length != 4) {
	                System.out.println("Invalid input format. Please try again.");
	                continue;
	            }
	            
	            String dateStr = parts[0];
	            String account = parts[1];
	            String typeStr = parts[2];
	            String amountStr = parts[3];
	            
	            try {
	                Date date = Bank.parseDate(dateStr);
	                
	                assertNotNull(date.toString());
	                TransactionType type = TransactionType.fromString(typeStr);
	                double amount = Double.parseDouble(amountStr);
	                
	                Transaction transaction = new Transaction(date, account, type, amount);
	                bank.addTransaction(transaction);
	                
	                System.out.println("Transaction added successfully.");
	                bank.printAccountStatement(account);
	            } catch (Exception e) {
	                System.out.println("Invalid input. Please try again.");
	            }
	        }
	    }
	    
	    @Test
	    public void defineInterestRules() throws Exception{
	        while (true) {
	            System.out.println("Please enter interest rules details in <Date> <RuleId> <Rate in %> format");
	            System.out.println("(or enter blank to go back to the main menu):");
	            System.out.println("> ");
	            
	            String input = "20230929 AC001 D 100.00";
	            
	            if (input.isEmpty()) {
	                break;
	            }
	            
	            String[] parts = input.split(" ");
	            
	            if (parts.length != 3) {
	                System.out.println("Invalid input format. Please try again.");
	                continue;
	            }
	            
	            String dateStr = parts[0];
	            String ruleId = parts[1];
	            String rateStr = parts[2];
	            
	            try {
	                Date date = Bank.parseDate(dateStr);
	                assertNotNull(date.toString());
	                double rate = Double.parseDouble(rateStr);
	                assertTrue(rate >0);
	                
	                InterestRule interestRule = new InterestRule(date, ruleId, rate);
	                bank.addInterestRule(interestRule);
	               	                
	                System.out.println("Interest rule added successfully.");
	                bank.printInterestRules();
	            } catch (Exception e) {
	                System.out.println("Invalid input. Please try again.");
	            }
	        }
	    }
	   
	    @Test
	    public void printStatement() throws Exception{
	        System.out.println("Please enter account and month to generate the statement <Account> <Year><Month>");
	        System.out.println("(or enter blank to go back to the main menu):");
	        System.out.println("> ");
	        
	        String input = "20231002 AC001 D 100.00";
	        
	        assertNotNull(input);
	        
	        if (input.isEmpty()) {
	            return;
	        }
	        
	        String[] parts = input.split(" ");
	        
	        assertNotNull(parts);
	        
	        if (parts.length != 2) {
	            System.out.println("Invalid input format. Please try again.");
	            return;
	        }
	        
	        String account = parts[0];
	        String yearMonth = parts[1];
	        
	        assertNotNull(account);
	        assertNotNull(yearMonth);
	        
	        bank.printAccountStatement(account, yearMonth);
	    }


}
