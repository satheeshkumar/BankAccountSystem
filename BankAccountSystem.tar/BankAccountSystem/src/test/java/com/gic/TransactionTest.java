package com.gic;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gic.util.Constants;


public class TransactionTest {
    // Set up Transaction instances and other necessary objects

	

	    @Test
	    public void testTransactionValidation() throws Exception{
	        // Your test logic for validating transaction constraints here
	    	
	    	// To Identify Deposit / Withdrawl case sceneario handling
	    	
	    	String transactionType="D";

		        if (transactionType.equalsIgnoreCase("D")) {
		        	
		        	assertNotNull(transactionType);
		        	assertEquals(transactionType,"D");

		        } else if (transactionType.equalsIgnoreCase("W")) {
		        	assertNotNull(transactionType);
		        	assertEquals(transactionType,"W");
			        } else {
		            throw new IllegalArgumentException(Constants.INVALID_TRANSACTION_TYPE+ transactionType);
		        }
		    
	    }
}