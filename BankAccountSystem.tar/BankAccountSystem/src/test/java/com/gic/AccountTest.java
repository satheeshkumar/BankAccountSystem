package com.gic;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.gic.account.Account;
import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;
import com.gic.transactionType.TransactionType;

public class AccountTest {
	
	String accountNumber="AC001";
	String pattern = "MM-dd-yyyy";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	String dateTrans = simpleDateFormat.format(new Date());
	int transactionCounter;
	String id;
	double balance=100.00;
	
	
	Account objAccount;//new Account(accountNumber, balance);
    List <Transaction>transactions=new ArrayList<Transaction>();


    public void Transaction(Date date, String account, TransactionType type, double amount) throws Exception {
    	
    	System.out.println(dateTrans);
         account="AC001";
         type=TransactionType.DEPOSIT;
         amount = 100.00;
         id = Bank.formatDate(date) + "-" + String.format("%02d", transactionCounter++);
    }
   
 
	

	private static final Logger logger = LogManager.getLogger(AccountTest.class);
	
	//@Test
	public void testBalance() throws Exception
	{
		 System.out.println("Balance: " + balance);
		assertNotNull(balance);
	}
	
	   
	//@Test
    public void testPrintStatement() throws Exception{
        System.out.println("Account: " + accountNumber);
        System.out.println("| Date::"+ dateTrans+"| Txn Id::"+ "20230601-01"
        		+"|Type::"+TransactionType.DEPOSIT+"| Amount::"+"100.00");
        for (Transaction transaction : transactions) {
            System.out.printf("| %s | %s | %s | %.2f |\n",
                    Bank.formatDate(transaction.getDate()), transaction.getId(),
                    transaction.getType(), transaction.getAmount());
        }
    }
    
    @Test
    public void testParamPrintStatement() throws Exception {
    	
    	String yearMonth="202309";
    	List<InterestRule> interestRules=new ArrayList<InterestRule>();
    	//interestRules.add("20230601-01 | D    | 150.00 |");   	
        System.out.println("Account: " + accountNumber);
        System.out.println("| Date::"+ dateTrans+"| Txn Id::"+ "20230601-01"
        		+"|Type::"+TransactionType.DEPOSIT+"| Amount::"+"100.00");
        
        List<Transaction> applicableTransactions = new ArrayList<>();
       // applicableTransactions.add(transactionCounter, "20230929 AC001 W 300.00");//"20230929 AC001 W 300.00"
        for (Transaction transaction : transactions) {
            System.out.printf("| %s | %s | %s | %.2f |\n",
                    Bank.formatDate(transaction.getDate()), transaction.getId(),
                    transaction.getType(), transaction.getAmount());
        }
        
        System.out.println("applicableTransactions.size(): " + applicableTransactions.size());
        assertTrue(applicableTransactions.size()>=0);
        double balance = 100.00;
        double rate = 2.5;
        System.out.println("balance: " + balance);
        assertTrue(getBalance()>=0); // to check for >0 value
      
        /*for (Transaction transaction : applicableTransactions) {
            System.out.printf("| %s | %s | %s | %.2f | %.2f |\n",
                    Bank.formatDate(transaction.getDate()), transaction.getId(),
                    transaction.getType(), transaction.getAmount(), balance);
            balance += (transaction.getType() == TransactionType.DEPOSIT ? transaction.getAmount() : -transaction.getAmount());
        }
        */

        //balance += (transaction.getType() == TransactionType.DEPOSIT ? transaction.getAmount() : -transaction.getAmount());
        double totalInterest = (balance * rate / 365.0);
        System.out.printf("| %s |             | I    | %.2f | %.2f |\n",
                getLastDayOfMonth(yearMonth), totalInterest, balance + totalInterest);
    }
    
    public double getBalance() throws Exception {
        double balance = 100;
        for (Transaction transaction : transactions) {
          //  balance += (transaction.getType() == TransactionType.DEPOSIT ? transaction.getAmount() : -transaction.getAmount());
            balance += -transaction.getAmount();
        }
        return balance;
    }
    
    private void  calculateInterestTest() throws Exception {
        double totalInterest = 0;
        double balance = getBalance();
        double rate = 2.5;
        assertTrue(getBalance()>0); // to check for >0 value
        String interestRules="20231002 RULE03 2.20";
        

            if (Bank.parseDate("202310") != null) {
                
                totalInterest += (balance * rate / 365.0); // Daily interest calculation
            }
        
        
        assertTrue(rate>0);
        assertTrue(totalInterest>0);

    }
    
    private String getLastDayOfMonth(String yearMonth) {
        int year = Integer.parseInt(yearMonth.substring(0, 4));
        int month = Integer.parseInt(yearMonth.substring(4, 6));
        int lastDay = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
        
        assertTrue(year>0);
        assertTrue(month>0);
        assertTrue(lastDay>0);
        
        return String.format("%04d%02d%02d", year, month, lastDay);
    }

    

}
