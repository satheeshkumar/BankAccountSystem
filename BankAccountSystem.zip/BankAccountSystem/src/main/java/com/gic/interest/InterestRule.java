package com.gic.interest;

import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.transaction.Transaction;

public class InterestRule {
	private static final Logger logger = LogManager.getLogger(InterestRule.class);
    private Date date;
    private String ruleId;
    private double rate;
    
    public InterestRule(Date date, String ruleId, double rate) {
        this.date = date;
        this.ruleId = ruleId;
        this.rate = rate;
    }
    
    public Date getDate() {
        return date;
    }
    
    public String getRuleId() {
        return ruleId;
    }
    
    public double getRate() {
        return rate;
    }
    

    private  void defineInterestRules(Scanner scanner, Bank bank) throws Exception{
        while (true) {
            logger.info("Please enter interest rules details in <Date> <RuleId> <Rate in %> format");
            logger.info("(or enter blank to go back to the main menu):");
            logger.info("> ");
            
            String input = scanner.nextLine();
            
            if (input.isEmpty()) {
                break;
            }
            
            String[] parts = input.split(" ");
            
            if (parts.length != 3) {
                logger.info("Invalid input format. Please try again.");
                continue;
            }
            
            String dateStr = parts[0];
            String ruleId = parts[1];
            String rateStr = parts[2];
            
            try {
                Date date = Bank.parseDate(dateStr);
                double rate = Double.parseDouble(rateStr);
                
                InterestRule interestRule = new InterestRule(date, ruleId, rate);
                bank.addInterestRule(interestRule);
                
                logger.info("Interest rule added successfully.");
                bank.printInterestRules();
            } catch (Exception e) {
                logger.info("Invalid input. Please try again.");
            }
        }
    }


 

}