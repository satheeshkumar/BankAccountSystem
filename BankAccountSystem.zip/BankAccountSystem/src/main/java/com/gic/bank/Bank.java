package com.gic.bank;

import com.gic.account.Account;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Bank {
	 private static final Logger logger = LogManager.getLogger(Bank.class); 
   private Map<String, Account> accounts;
   private List<InterestRule> interestRules;
   
   public Bank() {
       accounts = new HashMap<>();
       interestRules = new ArrayList<>();
   }
   
   public void addTransaction(Transaction transaction) throws Exception {
       String accountNumber = transaction.getAccount();
       Account account = accounts.getOrDefault(accountNumber, new Account(accountNumber));
       account.addTransaction(transaction);
       accounts.put(accountNumber, account);
   }
   
   public void addInterestRule(InterestRule rule) {
       // If there's any existing rules on the same day, the latest one is kept
       interestRules.removeIf(existingRule -> existingRule.getDate().equals(rule.getDate()));
       interestRules.add(rule);
       // Sort interest rules by date
       interestRules.sort(Comparator.comparing(InterestRule::getDate));
   }
   
   public void printInterestRules() {
       logger.info("Interest rules:");
       logger.info("| Date     | RuleId | Rate (%) |");
       for (InterestRule rule : interestRules) {
           System.out.printf("| %s | %s | %.2f |\n",
                   formatDate(rule.getDate()), rule.getRuleId(), rule.getRate());
       }
   }
   
   public void printAccountStatement(String accountNumber) throws Exception {
       Account account = accounts.get(accountNumber);
       if (account == null) {
           logger.info("Account not found.");
           return;
       }
       account.printStatement();
   }
   
   public void printAccountStatement(String accountNumber, String yearMonth) throws Exception {
       Account account = accounts.get(accountNumber);
       if (account == null) {
           logger.info("Account not found.");
           return;
       }
       account.printStatement(yearMonth, interestRules);
   }
   
   public static Date parseDate(String dateStr) throws java.text.ParseException {
       java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd");
       return sdf.parse(dateStr);
   }
   
   public static String formatDate(Date date) {
       java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd");
       return sdf.format(date);
   }
}