package com.gic.bankaccountsystem;

import java.util.*;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;
import com.gic.transactionType.TransactionType;

public class BankAccountSystem {

	private static final Logger logger = LogManager.getLogger(BankAccountSystem.class);
	private static List<Transaction> transactions;

	static Scanner scanner;
	static Date date = new Date();
	static List<InterestRule> interestRules;

	static double totalInterest;

	public static void main(String[] args) throws Exception {
		BasicConfigurator.configure();
		Scanner scanner = new Scanner(System.in);
		Bank bank = new Bank();

		while (true) {
			System.out.println("Welcome to AwesomeGIC Bank! What would you like to do?");
			System.out.println("[T] Input transactions");
			System.out.println("[I] Define interest rules");
			System.out.println("[P] Print statement");
			System.out.println("[Q] Quit");
			System.out.println("> ");

			String choice = scanner.nextLine();

			switch (choice.toUpperCase()) {
			case "T":
				inputTransactions(scanner, bank);
				break;
			case "I":
				try {
					totalInterest = defineInterestRules(scanner,date, interestRules);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}

				break;
			case "P":
				printStatement(scanner, bank);
				break;
			case "Q":
				System.out.println("Thank you for banking with AwesomeGIC Bank.");
				System.out.println("Have a nice day!");
				scanner.close();
				return;
			default:
				System.out.println("Invalid option. Please try again!!.");
				break;
			}
		}

	}

	/*
	 * printStatement(Scanner scanner, Bank bank) throws Exception args(Scanner,Bank
	 * bank)
	 */

	private static void printStatement(Scanner scanner, Bank bank) throws Exception {
		// TODO Auto-generated method stub

		System.out.println("Please enter account and month to generate the statement <Account> <Year><Month>");
		System.out.println("(or enter blank to go back to the main menu):");
		System.out.println("> ");

		String input = scanner.nextLine();

		if (input.isEmpty()) {
			return;
		}

		String[] parts = input.split(" ");

		if (parts.length != 2) {
			System.out.println("Invalid input arguments / format. Please try again.");
			return;
		}

		String account = parts[0];
		String yearMonth = parts[1];

		bank.printAccountStatement(account, yearMonth);
	}

	/*
	 * defineInterestRules(Scanner scanner, Bank bank) throws Exception args(Scanner
	 * scanner, Bank bank)
	 * 
	 */
	private static double defineInterestRules(Scanner scanner,Date date, List<InterestRule> interestRules) throws Exception{
		// TODO Auto-generated method stub
		
		 while (true) {
	            System.out.println("Please enter transaction details in <Date-YYYYMMdd> <RuleId-0X> <Rate-%> format");
	            System.out.println("(or enter blank to go back to the main menu):");
	            System.out.println("> ");
	            
	            String input = scanner.nextLine();
	            
	            if (input.isEmpty()) {
	                break;
	            }
	            
	            String[] parts = input.split(" ");
	            
	            if (parts.length != 3) {
	                System.out.println("Invalid input format. Please try again.");
	                continue;
	            }
	            
	            String yearMonth = parts[0];
	            String ruleID = parts[1];
	            String rateVal = parts[2];
	            
	           
	            	    double totalInterest = 0;
	                    double balance = 100;
	                    double rate;
	                    for (InterestRule rule : interestRules) {
	                        if (Bank.formatDate(rule.getDate()).startsWith(yearMonth)) {
	                            rate = rule.getRate() / 100.0;
	                            totalInterest += (balance * rate / 365.0); // Daily interest calculation
	                        }
	                    }
	                    System.out.println("totalInterest::"+totalInterest);
	                    
		 }       
	                    return totalInterest;
	              
	            
	        }

	public static double getBalance() {
		double balance = 0;
		try {
			for (Transaction transaction : transactions) {
				balance += (transaction.getType() == TransactionType.DEPOSIT ? transaction.getAmount()
						: -transaction.getAmount());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balance;
	}

	/*
	 * inputTransactions(Scanner scanner, Bank bank) throws Exception args(Scanner
	 * scanner, Bank bank)
	 * 
	 */
	private static void inputTransactions(Scanner scanner, Bank bank) throws Exception {
		// TODO Auto-generated method stub
		while (true) {
			System.out.println("Please enter transaction details in <Date> <Account> <Type> <Amount> format");
			System.out.println("(or enter blank to go back to the main menu):");
			System.out.println("> ");

			String input = scanner.nextLine();

			if (input.isEmpty()) {
				break;
			}

			String[] parts = input.split(" ");

			if (parts.length != 4) {
				System.out.println("Invalid input format. Please try again.");
				continue;
			}

			String dateStr = parts[0];
			String account = parts[1];
			String typeStr = parts[2];
			String amountStr = parts[3];

			try {
				Date date = Bank.parseDate(dateStr);
				TransactionType type = TransactionType.fromString(typeStr);
				double amount = Double.parseDouble(amountStr);

				Transaction transaction = new Transaction(date, account, type, amount);
				bank.addTransaction(transaction);

				System.out.println("Transaction added successfully.");
				bank.printAccountStatement(account);
			} catch (Exception e) {
				System.out.println("Invalid input. Please try again.");
			}
		}

	}

}