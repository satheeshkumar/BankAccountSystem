package com.gic.util;

public class Constants {
	
	public static String GIC_BANK_EXCEPTION="GIC BankAccountSystem Exception";
	
	public static String INVALID_TRANSACTION_TYPE="Invalid transaction type:";

}
