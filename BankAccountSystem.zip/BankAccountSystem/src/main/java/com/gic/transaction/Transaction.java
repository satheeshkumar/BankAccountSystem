package com.gic.transaction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gic.bank.Bank;
import com.gic.interest.InterestRule;
import com.gic.transactionType.TransactionType;

/*
 * author satheesh
 */
public class Transaction {
	private static final Logger logger = LogManager.getLogger(Transaction.class);
	private Date date;
	private String account;
	private TransactionType type;
	private double amount;
	private static int transactionCounter = 1;
	private String id;
	double balance;
	private List<Transaction> transactions=new ArrayList<Transaction>();

	// Constructor to form the param etc
	


	public Transaction(Date date, String account2, TransactionType type, double amount) throws Exception {
		this.date = date;
		this.account = account2;
		this.type = type;
		this.amount = amount;
		this.id = Bank.formatDate(date) + "-" + String.format("%02d", transactionCounter++);
	}

	public Date getDate() {
		return date;
	}
	
	
	public double getBalance() throws Exception{
        double balance = 0;
        for (Transaction transaction : transactions) {
            balance += transaction.getAmount();
            
            
        }
        return balance;
    }

	public String getAccount() throws Exception {
		
		this.balance=getBalance();
		
	     return (String)account;
	}

	/*
	 * Type 
	 * Withdraw (W)
	 * Deposit(D) 
	 * 
	 */
	public TransactionType getType() {
		return type;
	}

	public double getAmount() {
		return amount;
	}

	public String getId() {
		return id;
	}

	public static int getTransactionCounter() {
		return transactionCounter;
	}

	public static void setTransactionCounter(int transactionCounter) {
		Transaction.transactionCounter = transactionCounter;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	/*
	 * inputTransactions(Scanner scanner, Bank bank) throws Exception
	 * 
	 * args Scanner scanner, Bank bank
	 */
	private static void inputTransactions(Scanner scanner, Bank bank) throws Exception {
		while (true) {
			logger.info("Please enter transaction details in <Date> <Account> <Type> <Amount> format");
			logger.info("(or enter blank to go back to the main menu):");
			logger.info("> ");

			String input = scanner.nextLine();

			if (input.isEmpty()) {
				break;
			}

			String[] parts = input.split(" ");

			if (parts.length != 4) {
				logger.info("Invalid input format. Please try again!!.");
				continue;
			}

			String dateStr = parts[0];
			String account = parts[1];
			String typeStr = parts[2];
			String amountStr = parts[3];

			try {
				Date date = Bank.parseDate(dateStr);
				TransactionType type = TransactionType.fromString(typeStr);
				double amount = Double.parseDouble(amountStr);

				Transaction transaction = new Transaction(date, account, type, amount);
				bank.addTransaction(transaction);

				logger.info("Transaction added successfully.");
				bank.printAccountStatement(account);
			} catch (Exception e) {
				logger.info("Invalid input. Please try again.");
			}
		}
	}



	/* InterestRule Input Param
	 * <Date> <RuleId> <Rate in %> format
	 * defineInterestRules(Scanner scanner, Bank bank) throws Exception 
	 */
	private static void defineInterestRules(Scanner scanner, Bank bank) throws Exception {
		while (true) {
			logger.info("Please enter interest rules details in <Date> <RuleId> <Rate in %> format");
			logger.info("(or enter blank to go back to the main menu):");
			logger.info("> ");

			String input = scanner.nextLine();

			if (input.isEmpty()) {
				break;
			}

			String[] parts = input.split(" ");

			if (parts.length != 3) {
				logger.info("Invalid input format. Please try again.");
				continue;
			}

			String dateStr = parts[0];
			String ruleId = parts[1];
			String rateStr = parts[2];

			try {
				Date date = Bank.parseDate(dateStr);
				double rate = Double.parseDouble(rateStr);

				InterestRule interestRule = new InterestRule(date, ruleId, rate);
				bank.addInterestRule(interestRule);

				logger.info("Interest rule added successfully.");
				bank.printInterestRules();
			} catch (Exception e) {
				logger.info("Invalid input. Please try again.");
			}
		}
	}

	
	/* printStatement 
	 * @args <Account> <Year><Month> format
	 * printStatement(Scanner scanner, Bank bank) throws Exception 
	 */
	private static void printStatement(Scanner scanner, Bank bank) throws Exception {
		logger.info("Please enter account and month to generate the statement <Account> <Year><Month>");
		logger.info("(or enter blank to go back to the main menu):");
		logger.info("> ");

		String input = scanner.nextLine();

		if (input.isEmpty()) {
			return;
		}

		String[] parts = input.split(" ");

		if (parts.length != 2) {
			logger.info("Invalid input format. Please try again.");
			return;
		}

		String account = parts[0];
		String yearMonth = parts[1];

		bank.printAccountStatement(account, yearMonth);
	}
}
