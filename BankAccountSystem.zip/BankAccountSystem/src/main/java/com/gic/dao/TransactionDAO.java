package com.gic.dao;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

import com.gic.bank.Bank;
import com.gic.transactionType.TransactionType;

public interface TransactionDAO {

	 public void Transaction(Date date, String account, TransactionType type, double amount) throws ParseException;
	 
	 void inputTransactions(Scanner scanner, Bank bank)  throws Exception;
	 
	 void defineInterestRules(Scanner scanner, Bank bank) throws Exception;
}
