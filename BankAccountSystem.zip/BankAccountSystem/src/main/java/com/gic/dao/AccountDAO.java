package com.gic.dao;

import java.util.List;

import com.gic.interest.InterestRule;
import com.gic.transaction.Transaction;

public interface AccountDAO {
	
	public void addTransaction(Transaction transaction) throws Exception;
	public double getBalance() throws Exception;
	public void printStatement(String yearMonth, List<InterestRule> interestRules) throws Exception;
	
	
}
