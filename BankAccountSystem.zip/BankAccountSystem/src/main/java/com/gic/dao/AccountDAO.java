package com.gic.dao;

public interface AccountDAO {
	

}
