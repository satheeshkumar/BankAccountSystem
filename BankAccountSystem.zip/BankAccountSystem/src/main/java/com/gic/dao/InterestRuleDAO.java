package com.gic.dao;

import java.util.Date;

public interface InterestRuleDAO {
	
	  public void InterestRule(Date date, String ruleId, double rate) throws Exception;

}
