package com.gic;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;  

public class InterestCalculatorTest {

	private static final Logger logger = LogManager.getLogger(InterestCalculatorTest.class); 
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void interestCalculatorTest() throws Exception  {
		Scanner scanner = new Scanner(System.in);
        double totalInterest = 0.0;

        while (true) {
            System.out.println("Enter the number of days: ");
            int numDays = scanner.nextInt();
            if (numDays == 0) {
                break; // Exit the loop if 0 is entered
            }

            System.out.println("Enter the end of day balance: ");
            double eodBalance = scanner.nextDouble();

            System.out.println("Enter the rate id: ");
            String rateId = scanner.next();

            System.out.println("Enter the rate: ");
            double rate = scanner.nextDouble();

            double dailyInterest = (eodBalance * rate * numDays) / 36500.0;
            totalInterest += dailyInterest;

            System.out.println("Daily Interest: " + dailyInterest);
        }

        System.out.println("Total Interest: " + totalInterest);

        scanner.close();
    }
	}


